#!/bin/bash

# unix shell script to find or pick the zendemic tunnel base directory, and start up a jvm
# and run zendemic tunnel with that base directory

if [ "X" == "X$1" ] ; then
  echo You must supply a hostname to try and create a tunnel to.
  exit 1
fi

export HOSTNAME=$1

export ZTF=~/.zendemic_tunnel_path

export ZTJAR=zendemictunneljava.jar

if [ -e $ZTF ]; then
  export BASEDIR=`cat $ZTF`;
  # if the jar isn't there, the path is wrong, delete it.
  if [ ! -e $BASEDIR/zentunnel/$ZTJAR ] ; then
    rm $ZTF;
  fi
fi

CURRENTPATH="`dirname \"$0\"`"
FULLPATH="`( cd \"$CURRENTPATH\" && pwd )`"

if [ -e $ZTF ]; then
  # if it's still there, path is correct, use it.
  export BASEDIR=`cat $ZTF`;
else
  # look around for it
  export BASEDIR=$FULLPATH
  if [ -e $BASEDIR/zentunnel/$ZTJAR ] ; then
    echo $BASEDIR > $ZTF
  else
    export BASEDIR=`pwd`
    if [ -e $BASEDIR/zentunnel/$ZTJAR ] ; then
      echo $BASEDIR > $ZTF
    else
      export BASEDIR=`pwd`/zendemic
      if [ -e $BASEDIR/zentunnel/$ZTJAR ] ; then
        echo $BASEDIR > $ZTF
      else
        export BASEDIR=~/zendemic
        if [ -e $BASEDIR/zentunnel/$ZTJAR ] ; then
          echo $BASEDIR > $ZTF
        else
          echo "Can't find Zendemic Tunnel installation. Please run from install directory."
          exit
        fi
      fi
    fi
  fi
fi

echo "Zendemic Tunnel base directory (defined in $ZTF) is $BASEDIR"

# now find java

export JAVA=""

if [ -z "$JAVA_HOME" ]; then
  export JAVA=`which java`
  if [ -z "$JAVA" ]; then
    echo "Couldn't find a java installation. Make sure java is on your PATH."
    exit;
  fi
else
  export JAVA=$JAVA_HOME/bin/java
fi 

echo Running Zendemic Tunnel with this java: $JAVA


$JAVA -cp $BASEDIR/zentunnel/lib/bcprov-jdk15on-current.jar:$BASEDIR/zentunnel/$ZTJAR net.zendemic.tunnel.TunnelJava $BASEDIR $HOSTNAME
