@echo off

:: windows batch file to start up a jvm running a zendemic tunnel
:: the base directory will be determined by the execution path of this script
:: So where you extract the zendemictunnel_install.zip is where it will run.

set ZTJAR=zendemictunneljava.jar

set BASEDIR=%~dp0


if not [%1] == [] goto steptwo
  echo You must supply a hostname to try and create a tunnel to.
goto end

:steptwo

set HOSTNAME=%1

if exist %BASEDIR%\zentunnel\%ZTJAR% (
  echo found zendemic tunnel install
) else (
  echo Could not find Zendemic Tunnel installation. Please execute run_zendemic_tunnel.bat from the Zendemic Java Tunnel install directory where the zip was extracted.
  goto end
  )
)

echo Zendemic Tunnel base directory is %BASEDIR%

:: assume java is on the path

echo Running Zendemic Tunnel...


FOR /F "skip=2 tokens=2*" %%A IN ('REG QUERY "HKLM\Software\JavaSoft\Java Runtime Environment" /v CurrentVersion') DO set CurVer=%%B
ECHO %CurVer%


FOR /F "skip=2 tokens=2*" %%A IN ('REG QUERY "HKLM\Software\JavaSoft\Java Runtime Environment\%CurVer%" /v JavaHome') DO set JavaPath=%%B
ECHO %JavaPath%


"%JavaPath%\bin\java" -cp %BASEDIR%/zentunnel/lib/bcprov-jdk15on-150.jar;%BASEDIR%/zentunnel/%ZTJAR% net.zendemic.tunnel.TunnelJava %BASEDIR% %HOSTNAME%

:end
